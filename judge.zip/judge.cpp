#include <iostream>
#include <string>
#include <cstring>
#include <vector>
#include <fstream>
#include <sstream>
#include <Windows.h>
#include <cmath>
using namespace std;
double distan(int x1, int y1, int x2, int y2) {
	return sqrt((x1 - x2) * (x1 - x2) + (y1 - y2) * (y1 - y2));
}
int main() {

	ifstream res("resultPath.csv", ios::in);
	string lineStr;
	int totnum = 0;
	vector<vector<string>> resArray;
	while (getline(res, lineStr))
	{
		// ��ӡ�����ַ���
		cout << lineStr << endl;
		// ��ɶ�ά���ṹ
		stringstream ss(lineStr);
		string str;
		vector<string> lineArray;
		// ���ն��ŷָ�
		while (getline(ss, str, ','))
			lineArray.push_back(str);
		resArray.push_back(lineArray);
	}

	
	ifstream awnser("awnserPath", ios::in);
	vector<vector<string>> awnArray;

	while (getline(awnser, lineStr)) {
		totnum++;
		cout << lineStr << endl;
		stringstream ss(lineStr);
		string str;
		vector<string> lineArray;
		while (getline(ss, str, ','))
			lineArray.push_back(str);
		awnArray.push_back(lineArray);
	}
	double score = 0;
	int numrit = 0;
	int totstar = 0;
	for (int i = 0; i < totnum; i++) {
		if (stoi(awnArray[i][3]))
			totstar++;
	}
	for (int i = 0; i < totnum; i++) {
		if (stoi(awnArray[i][3])) {
			for (int j = 0; j < totnum; j++) {
				if (awnArray[i][0] == resArray[j][0]) {
					int x1 = stoi(awnArray[i][1]);
					int y1 = stoi(awnArray[i][2]);
					int x2 = stoi(resArray[i][1]);
					int y2 = stoi(resArray[i][2]);
					if (distan(x1, y1, x2, y2) < 15) {
						numrit++;
						break;
					}
					x2 = stoi(resArray[i][3]);
					y2 = stoi(resArray[i][4]);
					if (distan(x1, y1, x2, y2) < 15) {
						numrit++;
						break;
					}
					x2 = stoi(resArray[i][5]);
					y2 = stoi(resArray[i][6]);
					if (distan(x1, y1, x2, y2) < 15) {
						numrit++;
						break;
					}
				}
			}
		}
	}
	
	score = numrit * 1.0 / (totstar + 1.0);
	cout << score<<' ' <<totstar<<' '<<totnum<< endl;
	return 0;
}